<html>
<head>
<title>Request form</title>
</head>
<body>
<?php
if(!isset($_POST['fio']) and !isset($_POST['email'])){
?> <form action="send.php" method="post">
<?php
$fio = $_POST['fio'];
$email = $_POST['email'];
$fio = htmlspecialchars($fio);
$email = htmlspecialchars($email);
$fio = urldecode($fio);
$email = urldecode($email);
$fio = trim($fio);
$email = trim($email);
if (mail("adress e-mail", "Request", "Name:".$fio.". E-mail: ".$email ,"From: website e-mail \r\n"))
 {     echo "Message sent"; 
} else { 
    echo "Error";

}?>
